// Sample task data - Dados de exemplo das tarefas
let tasks = [
    { id: 1, title: "Criar apresentação", responsible: "Anna", dueDate: "2024-04-12", isCompleted: false, priority: "Alta", status: "Pendente" },
    { id: 2, title: "Revisar documentos", responsible: "Bruno", dueDate: "2024-04-15", isCompleted: false, priority: "Média", status: "Em Andamento" },
    { id: 3, title: "Atualizar site", responsible: "Carlos", dueDate: "2024-03-20", isCompleted: true, priority: "Baixa", status: "Concluída" },
    { id: 4, title: "Planejar reunião", responsible: "Diana", dueDate: "2024-04-25", isCompleted: false, priority: "Alta", status: "Pendente" },
    { id: 5, title: "Enviar relatórios", responsible: "Eduardo", dueDate: "2024-04-30", isCompleted: false, priority: "Média", status: "Pendente" },
    { id: 6, title: "Organizar arquivos", responsible: "Fernanda", dueDate: "2024-05-05", isCompleted: false, priority: "Baixa", status: "Pendente" },
    { id: 7, title: "Preparar orçamento", responsible: "Gustavo", dueDate: "2024-05-10", isCompleted: false, priority: "Alta", status: "Em Andamento" }
];

// Get DOM elements - Obtém os elementos do DOM
const taskTableBody = document.getElementById('taskTableBody');
const taskSearchInput = document.getElementById('taskSearch');
const addTaskBtn = document.getElementById('addTaskBtn');
const addTaskModal = document.getElementById('addTaskModal');
const closeModalButton = document.querySelector('.close-button');
const addTaskForm = document.getElementById('addTaskForm');

let tasksChart; // Chart.js instance

/**
 * Formats a date string from 'YYYY-MM-DD' to 'DD/MM/YYYY'.
 * Formata uma string de data de 'YYYY-MM-DD' para 'DD/MM/YYYY'.
 * @param {string} dateString - The date string in 'YYYY-MM-DD' format.
 * @returns {string} The formatted date string.
 */
function formatDate(dateString) {
    if (!dateString) return '';
    const [year, month, day] = dateString.split('-');
    return `${day}/${month}/${year}`;
}

/**
 * Renders the tasks into the HTML table.
 * Filtra as tarefas e as renderiza na tabela HTML.
 * @param {Array} tasksToRender - The array of tasks to display.
 */
function renderTasks(tasksToRender) {
    taskTableBody.innerHTML = ''; // Clear existing rows

    tasksToRender.forEach(task => {
        const row = document.createElement('tr');
        if (task.isCompleted) {
            row.classList.add('task-completed');
        }

        let priorityClass = '';
        switch (task.priority) {
            case 'Alta':
                priorityClass = 'priority-high';
                break;
            case 'Média':
                priorityClass = 'priority-medium';
                break;
            case 'Baixa':
                priorityClass = 'priority-low';
                break;
        }

        row.innerHTML = `
            <td><input type="checkbox" data-task-id="${task.id}" ${task.isCompleted ? 'checked' : ''} /></td>
            <td>${task.title}</td>
            <td>${task.responsible}</td>
            <td>${formatDate(task.dueDate)}</td>
            <td class="${priorityClass}">${task.priority}</td>
            <td>${task.status}</td>
            <td>
                <button class="delete-btn" data-task-id="${task.id}">🗑️</button>
            </td>
        `;
        taskTableBody.appendChild(row);
    });

    addCheckboxListeners();
    addDeleteButtonListeners(); // Add listeners for delete buttons
}

/**
 * Adds event listeners to all task completion checkboxes.
 */
function addCheckboxListeners() {
    document.querySelectorAll('input[type="checkbox"][data-task-id]').forEach(checkbox => {
        checkbox.removeEventListener('change', handleCheckboxChange); // Prevent duplicate listeners
        checkbox.addEventListener('change', handleCheckboxChange);
    });
}

function handleCheckboxChange(event) {
    const taskId = parseInt(event.target.dataset.taskId);
    const task = tasks.find(t => t.id === taskId);
    if (task) {
        task.isCompleted = event.target.checked;
        task.status = task.isCompleted ? 'Concluída' : (task.status === 'Em Andamento' ? 'Em Andamento' : 'Pendente');
        renderTasks(tasks);
        updateTasksChart();
    }
}

/**
 * Adds event listeners to all delete task buttons.
 */
function addDeleteButtonListeners() {
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.removeEventListener('click', handleDeleteTask); // Prevent duplicate listeners
        button.addEventListener('click', handleDeleteTask);
    });
}

function handleDeleteTask(event) {
    const taskId = parseInt(event.target.dataset.taskId);
    // Use a custom modal or message box instead of confirm()
    const confirmDelete = window.confirm('Tem certeza que deseja excluir esta tarefa?'); // Temporarily using confirm for simplicity
    if (confirmDelete) {
        tasks = tasks.filter(task => task.id !== taskId);
        renderTasks(tasks);
        updateTasksChart();
    }
}

/**
 * Handles the quick search functionality.
 */
taskSearchInput.addEventListener('keyup', (event) => {
    const searchTerm = event.target.value.toLowerCase();
    const filteredTasks = tasks.filter(task =>
        task.title.toLowerCase().includes(searchTerm) ||
        task.responsible.toLowerCase().includes(searchTerm)
    );
    renderTasks(filteredTasks);
});

// Event listeners for Add Task Modal
addTaskBtn.addEventListener('click', () => {
    addTaskModal.style.display = 'flex'; // Use flex to center
});

closeModalButton.addEventListener('click', () => {
    addTaskModal.style.display = 'none';
    addTaskForm.reset(); // Clear form fields
});

window.addEventListener('click', (event) => {
    if (event.target === addTaskModal) {
        addTaskModal.style.display = 'none';
        addTaskForm.reset();
    }
});

addTaskForm.addEventListener('submit', (event) => {
    event.preventDefault(); // Prevent default form submission

    const title = document.getElementById('taskTitle').value;
    const responsible = document.getElementById('taskResponsible').value;
    const dueDate = document.getElementById('taskDueDate').value; // YYYY-MM-DD format
    const priority = document.getElementById('taskPriority').value;

    const newId = tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1;

    const newTask = {
        id: newId,
        title: title,
        responsible: responsible,
        dueDate: dueDate,
        isCompleted: false,
        priority: priority,
        status: 'Pendente' // New tasks are always pending
    };

    tasks.push(newTask);
    renderTasks(tasks); // Re-render table with new task
    updateTasksChart(); // Update chart
    addTaskModal.style.display = 'none'; // Close modal
    addTaskForm.reset(); // Clear form fields
});

/**
 * Updates the Chart.js graph with current task status distribution.
 */
function updateTasksChart() {
    const statusCounts = tasks.reduce((acc, task) => {
        acc[task.status] = (acc[task.status] || 0) + 1;
        return acc;
    }, {});

    const labels = Object.keys(statusCounts);
    const data = Object.values(statusCounts);

    const backgroundColors = labels.map(label => {
        switch (label) {
            case 'Pendente':
                return '#FFC107'; // Amarelo
            case 'Em Andamento':
                return '#17A2B8'; // Azul claro
            case 'Concluída':
                return '#28A745'; // Verde
            default:
                return '#6C757D'; // Cinza
        }
    });

    if (tasksChart) {
        tasksChart.data.labels = labels;
        tasksChart.data.datasets[0].data = data;
        tasksChart.data.datasets[0].backgroundColor = backgroundColors;
        tasksChart.update();
    } else {
        const ctx = document.getElementById('tasksChart').getContext('2d');
        tasksChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Número de Tarefas',
                    data: data,
                    backgroundColor: backgroundColors,
                    borderColor: '#fff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Distribuição de Tarefas por Status'
                    }
                }
            }
        });
    }
}

// Initial rendering of tasks and chart when the page loads
document.addEventListener('DOMContentLoaded', () => {
    renderTasks(tasks);
    updateTasksChart();
    // ESSA É A LINHA CRUCIAL PARA GARANTIR QUE O MODAL ESTEJA ESCONDIDO NO CARREGAMENTO
    addTaskModal.style.display = 'none';
});

// Basic sidebar toggle (from your original script.js)
function openSidebar() {
    document.getElementById('sidebar').style.width = '250px';
}

function closeSidebar() {
    document.getElementById('sidebar').style.width = '0';
}
