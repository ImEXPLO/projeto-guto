// Dados de exemplo para as equipes (simulando um banco de dados)
let equipes = [
    {
        id: 1,
        nome: "Marketing",
        descricao: "Responsável pelas campanhas de comunicação da prefeitura.",
        lider: "Ana Silva",
        membros: ["João", "Maria", "Pedro"],
        projetosAtivos: 3,
        icone: "https://img.icons8.com/color/48/pie-chart.png"
    },
    {
        id: 2,
        nome: "Desenvolvimento",
        descricao: "Criação e manutenção de sistemas e aplicativos para a prefeitura.",
        lider: "Carlos Souza",
        membros: ["Lucas", "Fernanda", "Rafael"],
        projetosAtivos: 5,
        icone: "https://img.icons8.com/fluency/48/source-code.png"
    },
    {
        id: 3,
        nome: "Vendas", // Pode ser "Atendimento ao Cidadão" ou "Arrecadação" em um contexto municipal
        descricao: "Gestão da arrecadação e atendimento ao público para serviços específicos.",
        lider: "Mariana Costa",
        membros: ["Julia", "Roberto"],
        projetosAtivos: 2,
        icone: "https://img.icons8.com/fluency/48/money-bag.png"
    },
    {
        id: 4,
        nome: "Suporte",
        descricao: "Oferece suporte técnico e atendimento a demandas internas e externas.",
        lider: "Paulo Mendes",
        membros: ["Gabriela"],
        projetosAtivos: 1,
        icone: "https://img.icons8.com/fluency/48/help.png"
    }
];

const equipesContainer = document.getElementById('equipesContainer');
const searchEquipeInput = document.getElementById('searchEquipe');
const btnCriarEquipe = document.getElementById('btnCriarEquipe');

// Elementos do Modal de Criar/Editar
const modalEquipe = document.getElementById('modalEquipe');
const modalEquipeTitle = document.getElementById('modalEquipeTitle');
const formEquipe = document.getElementById('formEquipe');
const equipeIdInput = document.getElementById('equipeId');
const equipeNomeInput = document.getElementById('equipeNome');
const equipeDescricaoInput = document.getElementById('equipeDescricao');
const equipeLiderInput = document.getElementById('equipeLider');
const equipeMembrosInput = document.getElementById('equipeMembros');
const cancelarEquipeModalBtn = document.getElementById('cancelarEquipeModal');

// Elementos do Modal de Detalhes
const modalDetalhesEquipe = document.getElementById('modalDetalhesEquipe');
const detalhesEquipeNome = document.getElementById('detalhesEquipeNome');
const detalhesEquipeDescricao = document.getElementById('detalhesEquipeDescricao');
const detalhesEquipeLider = document.getElementById('detalhesEquipeLider');
const detalhesEquipeMembros = document.getElementById('detalhesEquipeMembros');
const detalhesEquipeProjetos = document.getElementById('detalhesEquipeProjetos');
const fecharDetalhesEquipeModalBtn = document.getElementById('fecharDetalhesEquipeModal');

// Elementos do Modal de Exclusão
const modalConfirmacaoExclusao = document.getElementById('modalConfirmacaoExclusao');
const confirmarExclusaoBtn = document.getElementById('confirmarExclusao');
const cancelarExclusaoBtn = document.getElementById('cancelarExclusao');

let equipeParaExcluirId = null;

// Função para renderizar os cartões das equipes
function renderEquipes(filtro = '') {
    equipesContainer.innerHTML = ''; 
    const equipesFiltradas = equipes.filter(equipe =>
        equipe.nome.toLowerCase().includes(filtro.toLowerCase()) ||
        equipe.descricao.toLowerCase().includes(filtro.toLowerCase()) ||
        equipe.lider.toLowerCase().includes(filtro.toLowerCase())
    );

    if (equipesFiltradas.length === 0) {
        equipesContainer.innerHTML = '<p style="color: white; text-align: center; grid-column: 1 / -1;">Nenhuma equipe encontrada.</p>';
        return;
    }

    equipesFiltradas.forEach(equipe => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <img src="${equipe.icone || 'https://img.icons8.com/fluency/48/group.png'}" alt="${equipe.nome}"/>
            <h2>${equipe.nome}</h2>
            <p>Membros: ${equipe.membros ? equipe.membros.length : 0}</p>
            <p>Projetos Ativos: ${equipe.projetosAtivos}</p>
            <div class="equipe-actions">
                <button class="btn-detalhes" data-id="${equipe.id}">Detalhes</button>
                <button class="btn-editar" data-id="${equipe.id}">Editar</button>
                <button class="btn-excluir" data-id="${equipe.id}">
                    <span class="material-icons-outlined">delete</span>
                </button>
            </div>
        `;
        equipesContainer.appendChild(card);
    });

    attachEventListeners();
}

// Anexa os event listeners aos botões
function attachEventListeners() {
    document.querySelectorAll('.btn-detalhes').forEach(button => {
        button.addEventListener('click', (e) => openDetalhesEquipeModal(parseInt(e.currentTarget.dataset.id)));
    });
    document.querySelectorAll('.btn-editar').forEach(button => {
        button.addEventListener('click', (e) => openEquipeModalForEdit(parseInt(e.currentTarget.dataset.id)));
    });
    document.querySelectorAll('.btn-excluir').forEach(button => {
        button.addEventListener('click', (e) => openConfirmacaoExclusaoModal(parseInt(e.currentTarget.dataset.id)));
    });
}

// Abre o modal de criação de equipe
btnCriarEquipe.addEventListener('click', () => {
    modalEquipeTitle.textContent = 'Criar Nova Equipe';
    formEquipe.reset();
    equipeIdInput.value = '';
    modalEquipe.style.display = 'flex';
});

// Abre o modal para edição
function openEquipeModalForEdit(id) {
    const equipe = equipes.find(e => e.id === id);
    if (equipe) {
        modalEquipeTitle.textContent = 'Editar Equipe';
        equipeIdInput.value = equipe.id;
        equipeNomeInput.value = equipe.nome;
        equipeDescricaoInput.value = equipe.descricao;
        equipeLiderInput.value = equipe.lider;
        equipeMembrosInput.value = equipe.membros ? equipe.membros.join(', ') : '';
        modalEquipe.style.display = 'flex';
    }
}

// Fecha o modal de equipe
cancelarEquipeModalBtn.addEventListener('click', () => {
    modalEquipe.style.display = 'none';
});

// Lida com o envio do formulário
formEquipe.addEventListener('submit', (e) => {
    e.preventDefault();
    const id = equipeIdInput.value ? parseInt(equipeIdInput.value) : null;
    const nome = equipeNomeInput.value;
    const descricao = equipeDescricaoInput.value;
    const lider = equipeLiderInput.value;
    const membros = equipeMembrosInput.value.split(',').map(m => m.trim()).filter(Boolean);

    if (id) {
        const index = equipes.findIndex(e => e.id === id);
        if (index !== -1) {
            equipes[index] = { ...equipes[index], nome, descricao, lider, membros };
        }
    } else {
        const newId = equipes.length > 0 ? Math.max(...equipes.map(e => e.id)) + 1 : 1;
        equipes.push({
            id: newId, nome, descricao, lider, membros,
            projetosAtivos: 0,
            icone: 'https://img.icons8.com/fluency/48/group.png'
        });
    }

    renderEquipes(searchEquipeInput.value);
    modalEquipe.style.display = 'none';
});

// Abre o modal de detalhes
function openDetalhesEquipeModal(id) {
    const equipe = equipes.find(e => e.id === id);
    if (equipe) {
        detalhesEquipeNome.textContent = equipe.nome;
        detalhesEquipeDescricao.textContent = equipe.descricao;
        detalhesEquipeLider.textContent = equipe.lider;
        detalhesEquipeMembros.textContent = equipe.membros && equipe.membros.length > 0 ? equipe.membros.join(', ') : 'Nenhum membro cadastrado.';
        detalhesEquipeProjetos.textContent = equipe.projetosAtivos;
        modalDetalhesEquipe.style.display = 'flex';
    }
}

fecharDetalhesEquipeModalBtn.addEventListener('click', () => {
    modalDetalhesEquipe.style.display = 'none';
});

// Abre o modal de confirmação de exclusão
function openConfirmacaoExclusaoModal(id) {
    equipeParaExcluirId = id;
    modalConfirmacaoExclusao.style.display = 'flex';
}

// Ações de exclusão
confirmarExclusaoBtn.addEventListener('click', () => {
    if (equipeParaExcluirId !== null) {
        equipes = equipes.filter(e => e.id !== equipeParaExcluirId);
        renderEquipes(searchEquipeInput.value);
        modalConfirmacaoExclusao.style.display = 'none';
        equipeParaExcluirId = null;
    }
});

cancelarExclusaoBtn.addEventListener('click', () => {
    modalConfirmacaoExclusao.style.display = 'none';
    equipeParaExcluirId = null;
});

// Busca dinâmica
searchEquipeInput.addEventListener('input', (e) => {
    renderEquipes(e.target.value);
});

// Fechar modais ao clicar fora
window.addEventListener('click', (e) => {
    if (e.target === modalEquipe) modalEquipe.style.display = 'none';
    if (e.target === modalDetalhesEquipe) modalDetalhesEquipe.style.display = 'none';
    if (e.target === modalConfirmacaoExclusao) modalConfirmacaoExclusao.style.display = 'none';
});


// Renderiza na carga inicial da página
document.addEventListener('DOMContentLoaded', () => {
    renderEquipes();
});